var mysql = require('mysql');

var con = mysql.createConnection({
  host: "46.101.75.221",
  user: "ezeyqsbbpd",
  password: "r59k4yWyPa",
  database: "ezeyqsbbpd"
});

con.connect(function(err) {
  if (err) throw err;
  else
  console.log("Connected!");
});